import pygame
import asyncio
import random

pygame.init()

WIDTH, HEIGHT = 900, 700
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Simple Slot Machine")

clock = pygame.time.Clock()

TITLE_FONT = pygame.font.SysFont(None, 64)
FONT = pygame.font.SysFont(None, 36)

symbols = ["7", "$", "BAR", "A", "K", "*"]

reels = [random.choice(symbols) for _ in range(3)]
final = reels[:]

coins = 100
jackpot = 5000
message = "Click SPIN"

spin_button = pygame.Rect(325, 560, 250, 60)
reset_button = pygame.Rect(325, 630, 250, 50)

spinning = False
spin_start = 0
spin_length = 2000


async def main():
    global reels, final
    global coins, jackpot, message
    global spinning, spin_start

    running = True

    while running:

        clock.tick(60)

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN:

                # ---------------- SPIN ----------------

                if spin_button.collidepoint(event.pos):

                    if not spinning and coins >= 5:

                        coins -= 5
                        jackpot += 5

                        spinning = True
                        spin_start = pygame.time.get_ticks()

                        final = [
                            random.choice(symbols),
                            random.choice(symbols),
                            random.choice(symbols),
                        ]

                        message = "Spinning..."

                # ---------------- RESET ----------------

                elif reset_button.collidepoint(event.pos):

                    coins = 100
                    jackpot = 5000

                    reels = [
                        random.choice(symbols),
                        random.choice(symbols),
                        random.choice(symbols),
                    ]

                    final = reels[:]

                    spinning = False
                    message = "Game Reset"

        # ---------------- SPIN ANIMATION ----------------

        if spinning:

            reels = [
                random.choice(symbols),
                random.choice(symbols),
                random.choice(symbols),
            ]

            if pygame.time.get_ticks() - spin_start >= spin_length:

                spinning = False
                reels = final[:]

                a, b, c = reels

                if a == b == c:

                    if a == "7":

                        coins += jackpot
                        message = f"JACKPOT! +{jackpot}"
                        jackpot = 5000

                    else:

                        coins += 100
                        message = "WIN! +100"

                elif a == b or a == c or b == c:

                    coins += 10
                    message = "PAIR! +10"

                else:

                    message = "LOSE"

        # ---------------- DRAW ----------------

        screen.fill((40, 0, 70))

        title = TITLE_FONT.render(
            "SLOT MACHINE",
            True,
            (255, 215, 0),
        )

        screen.blit(title, title.get_rect(center=(450, 50)))

        pygame.draw.rect(
            screen,
            (255, 215, 0),
            (70, 100, 760, 240),
            border_radius=20,
        )

        pygame.draw.rect(
            screen,
            (25, 25, 25),
            (85, 115, 730, 210),
            border_radius=15,
        )

        # Reels
        for i in range(3):

            x = 120 + i * 230

            pygame.draw.rect(
                screen,
                (255, 255, 255),
                (x, 145, 160, 150),
                border_radius=10,
            )

            txt = TITLE_FONT.render(
                reels[i],
                True,
                (0, 0, 0),
            )

            screen.blit(
                txt,
                txt.get_rect(center=(x + 80, 220)),
            )

        # Stats
        screen.blit(
            FONT.render(
                f"Coins: {coins}",
                True,
                (255, 255, 255),
            ),
            (40, 380),
        )

        screen.blit(
            FONT.render(
                f"Jackpot: {jackpot}",
                True,
                (255, 215, 0),
            ),
            (40, 420),
        )

        screen.blit(
            FONT.render(
                message,
                True,
                (255, 255, 255),
            ),
            (40, 460),
        )

        # Spin Button
        pygame.draw.rect(
            screen,
            (0, 180, 0),
            spin_button,
            border_radius=12,
        )

        txt = FONT.render(
            "SPIN",
            True,
            (255, 255, 255),
        )

        screen.blit(
            txt,
            txt.get_rect(center=spin_button.center),
        )

        # Reset Button
        pygame.draw.rect(
            screen,
            (180, 0, 0),
            reset_button,
            border_radius=12,
        )

        txt = FONT.render(
            "RESET",
            True,
            (255, 255, 255),
        )

        screen.blit(
            txt,
            txt.get_rect(center=reset_button.center),
        )

        pygame.display.flip()

        await asyncio.sleep(0)

    pygame.quit()


asyncio.run(main())